package my.nat.tvmaze.interfaces;

import java.util.ArrayList;

import my.nat.tvmaze.data.entities.TvShow;

public interface TvShowInteractor {

    void getShowListInteractor(int page);

}
