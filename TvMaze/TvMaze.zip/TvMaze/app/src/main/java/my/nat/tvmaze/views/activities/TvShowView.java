package my.nat.tvmaze.views.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.tvmaze.R;

import java.util.List;

import my.nat.tvmaze.SplashScreen;
import my.nat.tvmaze.data.entities.TvShow;
import my.nat.tvmaze.views.fragment.TvShowsFragment;

//Implemento la IView de mi activity

public class TvShowView extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFragment(new TvShowsFragment());


    }
    private void setFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.content, fragment).commit();
    }

    }

