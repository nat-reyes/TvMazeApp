package my.nat.tvmaze.data.entities;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Image implements Serializable {

    @SerializedName("medium")
    @Expose
    private String medium;
    @SerializedName("original")
    @Expose
    private String original;

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }

    public String getOriginal() {
        return original;
    }

    public void setOriginal(String original) {
        this.original = original;
    }
//TODO QUITAR LOS TOSTRING
    @Override
    public String toString() {
        return "Image{" +
                "medium='" + medium + '\'' +
                ", original='" + original + '\'' +
                '}';
    }

}
