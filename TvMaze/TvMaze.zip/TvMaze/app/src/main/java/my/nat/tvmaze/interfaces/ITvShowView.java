package my.nat.tvmaze.interfaces;

import java.util.ArrayList;
import java.util.List;

import my.nat.tvmaze.data.entities.TvShow;

public interface ITvShowView {

    void showLoading();
    void hideLoading();
    void setDataReceived(ArrayList<TvShow> tvShows);
    void onErrorLoading(String message);

}
