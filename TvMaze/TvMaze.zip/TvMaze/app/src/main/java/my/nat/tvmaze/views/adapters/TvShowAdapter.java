package my.nat.tvmaze.views.adapters;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tvmaze.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import my.nat.tvmaze.data.entities.TvShow;
import my.nat.tvmaze.views.fragment.TvShowsFragment;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.ViewHolder> {

    private ArrayList<TvShow> mData;
    private LayoutInflater mInflater;
    private AdapterView.OnItemClickListener mClickListener;
    TvShowsFragment context;

    public TvShowAdapter(Context context, ArrayList<TvShow> mData) {
        this.mInflater = LayoutInflater.from(context);
         this.mData = mData;
    }

    @Override
    public TvShowAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = mInflater.inflate(R.layout.fragment_cardview_tvshow, parent, false);
     return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TvShowAdapter.ViewHolder holder, int position) {
    //Aqui lleno lo que mostrare con los datos que recibo
       //TODO ENVIAR A LA OTRA VISTA
        TvShow Item = mData.get(position);
        holder.tittle.setText(Item.getName());
        if (!Item.getImage().getMedium().equalsIgnoreCase("")){
            Picasso.get().load(Item.getImage().getOriginal()).resize(300,350).into(holder.poster);
        }


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        @BindView(R.id.tvTitleShow)
        TextView tittle;
        @BindView(R.id.imageViewShow)
        ImageView poster;
        @BindView(R.id.LinearPoster)
        RelativeLayout listen;
        private Context context;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //TODO SHOW THIS BUTTERNIFE
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(this);
        }

        void setOnClickListener(){
            listen.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
         //TODO INFLATE THE LAYOUT THAT I NEED
        }
    }
}
