package my.nat.tvmaze.interfaces;

import java.util.ArrayList;
import java.util.List;

import my.nat.tvmaze.data.entities.TvShow;

public interface TvShowPresenter {

    void onShowError(String error);
    void getListShows(int page);
    void showList(ArrayList<TvShow> movieArrayList);

}
