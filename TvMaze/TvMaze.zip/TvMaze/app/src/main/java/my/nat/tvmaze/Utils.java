package my.nat.tvmaze;
import my.nat.tvmaze.data.API.*;


public class Utils {

    /*public static TvMazeAPI getApi() {
        return TvMazeClient.getApiMaze().create(TvMazeAPI.class);
    }
*/
}
