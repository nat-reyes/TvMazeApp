package my.nat.tvmaze.data.API;

import java.util.List;

import my.nat.tvmaze.data.entities.TvShow;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TvMazeAPI {

    @GET("show")
    Call<List<TvShow>> getShows(@Query("page") int page);



}
