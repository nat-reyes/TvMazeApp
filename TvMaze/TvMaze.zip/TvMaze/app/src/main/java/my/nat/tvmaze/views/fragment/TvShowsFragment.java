package my.nat.tvmaze.views.fragment;

import android.graphics.Color;
import android.graphics.Movie;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tvmaze.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import my.nat.tvmaze.GridSpacingItemDecoration;
import my.nat.tvmaze.data.entities.TvShow;
import my.nat.tvmaze.interfaces.TvShowPresenter;
import my.nat.tvmaze.interfaces.ITvShowView;
import my.nat.tvmaze.views.adapters.TvShowAdapter;

//recycle con el listado de movies
//El recycle tiene un card view con la info que llevara cada item
//text de tittle

public class TvShowsFragment extends Fragment implements ITvShowView {

    @BindView(R.id.progress_bar)
    ProgressBar progress_bar;
    @BindView(R.id.recycle_tvshows)
    RecyclerView showsRecycle;
    @BindView(R.id.first_number)
    TextView first_num;
    @BindView(R.id.second_number)
    TextView second_num;
    @BindView(R.id.third_number)
    TextView third_num;
    @BindView(R.id.next)
    TextView next;
    @BindView(R.id.back)
    TextView back;
    int snaped;
    private TvShowPresenter presenter;
    private ArrayList<TvShow> shows;
    private TvShowAdapter adapter;
    private static final int incr = 3;


    public TvShowsFragment() {

    }


    @Override
    public android.view.View onCreateView(LayoutInflater inflater, ViewGroup container,
                                          Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        android.view.View view= inflater.inflate(R.layout.fragment_list_tvshows, container, false);
        ButterKnife.bind(this, view);
        shows = new ArrayList<>();
        presenter = new my.nat.tvmaze.presenter.TvShowPresenter(this);
        //TODO Mandarle el numero de pagina que arroje el componente
        presenter.getListShows(1);
        initListeners();
        return view;
    }

    @Override
    public void showLoading() {
            progress_bar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
            progress_bar.setVisibility(View.GONE);

    }

    @Override
    public void setDataReceived(ArrayList<TvShow> tvShows) {
        cargarRecycleView(tvShows);
        shows.addAll(tvShows);

    }



    public void initListeners(){

        first_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                presenter.getListShows(Integer.parseInt(first_num.getText().toString()));
                snapText(first_num);
            }
        });
        second_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.getListShows(Integer.parseInt(second_num.getText().toString()));
                snapText(second_num);

            }
        });

        third_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.getListShows(Integer.parseInt(third_num.getText().toString()));
                snapText(third_num);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changePage(0);

                //presenter.getListShows(Integer.parseInt(first_num.getText().toString()));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!first_num.getText().toString().equalsIgnoreCase("1")){
                    changePage(1);
                }

                //presenter.getListShows(Integer.parseInt(first_num.getText().toString()));
            }
        });

    }

    //TODO SNAP TEXT
    public void snapText(TextView text){
        SpannableString mitextoU = new SpannableString(text.getText().toString());
        mitextoU.setSpan(new UnderlineSpan(), 0, mitextoU.length(), 0);
        text.setText(mitextoU);
    }

    public void changePage(int action){
        if(action == 0){
            first_num.setText(String.valueOf(Integer.parseInt(first_num.getText().toString())+incr));
            second_num.setText(String.valueOf(Integer.parseInt(second_num.getText().toString())+incr));
            third_num.setText(String.valueOf(Integer.parseInt(third_num.getText().toString())+incr));
        }else if (action==1){
            first_num.setText(String.valueOf(Integer.parseInt(first_num.getText().toString())-incr));
            second_num.setText(String.valueOf(Integer.parseInt(second_num.getText().toString())-incr));
            third_num.setText(String.valueOf(Integer.parseInt(third_num.getText().toString())-incr));
        }

    }




    public void cargarRecycleView(ArrayList<TvShow> tvShows){
        GridLayoutManager grid = new GridLayoutManager(getContext(), 2);
       // showsRecycle.addItemDecoration(new GridSpacingItemDecoration(2, GridSpacingItemDecoration.dpToPx(getContext(), 10), true));
        showsRecycle.setItemAnimator(new DefaultItemAnimator());
        // TODO SHOW THAT GETACTIVITY IDK IF IS THAT POSSIBLE
        showsRecycle.setLayoutManager(grid);
        //TODO I AM SENDING A FRAGMEN EYES
        adapter = new TvShowAdapter(getContext(),tvShows);
        showsRecycle.setAdapter(adapter);


    }





    @Override
    public void onErrorLoading(String message) {
        Toast.makeText(getActivity(),message,Toast.LENGTH_SHORT).show();
        // TODO Revisar si se puede ese getactivity
    }




}
