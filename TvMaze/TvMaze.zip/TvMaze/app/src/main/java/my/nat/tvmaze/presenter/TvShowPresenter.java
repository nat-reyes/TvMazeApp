package my.nat.tvmaze.presenter;

import java.util.ArrayList;

import my.nat.tvmaze.data.entities.TvShow;
import my.nat.tvmaze.interfaces.TvShowInteractor;
import my.nat.tvmaze.interfaces.ITvShowView;

public class TvShowPresenter implements my.nat.tvmaze.interfaces.TvShowPresenter {

    private ITvShowView view;
    private TvShowInteractor interactor;

    public TvShowPresenter(ITvShowView view){
        this.view = view;
        interactor = new my.nat.tvmaze.interactors.TvShowInteractor(this);
    }

    @Override
    public void onShowError(String error) {
        if(view==null){
            view.hideLoading(); // progressbar
            view.onErrorLoading(error);// showerror
        }

    }

    @Override
    public void getListShows(int page) {
        if(view!=null){
            view.showLoading();
            interactor.getShowListInteractor(page);
        }
    }
   @Override
    public void showList(ArrayList<TvShow> tvShows) {
        if (view != null) {
            view.hideLoading();
        }
       view.setDataReceived(tvShows);
    }



/*
    public void getTvShowByPage(int page){


    }
    */

}
